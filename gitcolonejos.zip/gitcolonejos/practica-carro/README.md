# PRACTICA CARRITO COMPRA
##### Daniel Garcia Diaz

## DESCRIPCION:
Se trata de una pequeña práctica en la que desarrollar lo aprendido en el curso sobre Java.
Es un carrito de la compra, en el que se simula la compra de diferentes productos por un cliente.
Este consta de un pequeño menu en el que se puede iniciar como Empresa o como Cliente, la idea de esto es diferenciar las
diferentes funciones que van a tener los usuarios, sabiendo que los clientes pueden comprar los productos y la empresa puede 
aumentar o disminuir el stock de los mismos.

### CLASES 
* PRODUCTOS: Contiene los atributos y metodos referentes a los productos.
* CLIENTES: Contiene los atributos y metodos referentes a los clientes.
* CATEGORIAS: Contiene los atributos y metodos referentes a las categorias.
* SISTEMA: Es la clase principal del proyecto, donde se desarrollan todos los metodos que dan funcionalidad.
* MAIN: Muestra el menu principal del proyecto.
